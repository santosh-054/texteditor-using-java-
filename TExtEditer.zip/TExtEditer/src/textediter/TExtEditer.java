
package textediter;

import javax.swing.JFrame;


public class TExtEditer {
    private static TextEditerFrame TextEditerFrame;

    
    public static void main(String[] args) {
        // TODO code application logic here
       TextEditerFrame frame = new TextEditerFrame();
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.setVisible(true);
    }
        
}
